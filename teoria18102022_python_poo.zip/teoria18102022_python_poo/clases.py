from datetime import datetime


class Clientenuevo:
    def __init__(self,f) -> None:
        self.facturacion=f
    def calcularTotal(self):#método de clase
        print('calculando el total')

clientenuevo1=Clientenuevo(30000)#instanciar un objeto
clientenuevo1.calcularTotal()
clientenuevo1.facturacion=40000 #setter
print(clientenuevo1.facturacion)#4000getter

#crea una clase llamada Producto
#los productos tendrán nombre, unidades y precio
#crea el siguiente producto: camisa,20,9,95
#muestra por pantalla el detalle del producto

class Producto:
    def __init__(self,nombre,unidades,precio) -> None:#constructor
        self.nombre=nombre
        self.unidades=unidades
        self.precio=precio
    def verdetalles(self):
        print(f'El producto es: {self.nombre} - {self.unidades} - {self.precio}')
    def consultarPrecio(self):
        if (self.unidades>50):
            self.precio=self.precio*0.9
        print(f'el precio final es: {self.precio}')

producto1=Producto('camisa',20,9.95)
producto1.verdetalles()
producto2=Producto('pantalones',20,9.95)
producto2.verdetalles()
producto3=Producto('abrigo',20,9.95)
producto3.verdetalles()
producto1.consultarPrecio()
producto2.consultarPrecio()
producto3.consultarPrecio()

#crea un método en la clase Producto llamado consultarPrecio
#si las unidades son + de 50, el precio final tiene un 10% de descuento
#da de alta el producto:sombrero,40,12.95
#da de alta el producto:chaqueta,60,25.95
#muestra el detalle de los dos productos

producto4=Producto('sombrero',40,12.95)
producto5=Producto('chaqueta',60,25.95)
producto4.consultarPrecio
producto5.consultarPrecio
  

#crea una clase para gestionar empleados
#damos de alta al empleado:Luis López,2500 euros de salario bruto,
#aministrativo
#muestra por consola el detalle del empleado.

class Empleados:
    def __init__(self,nombre,salario,puesto) -> None:
        self.nombre=nombre
        self.salario=salario
        self.puesto=puesto
    def verdetalles(self):
        print(f'El empleado ES :{self.nombre} - {self.salario} - {self.puesto}')
    def consultarsalario(self):
        self.salario=self.salario*0.85
        print(f'el salario final es:{self.salario*0.85}')

empleado1=Empleados('Luis López',2500,'administrativo')
empleado1.verdetalles()

#Contratamos a otro empleado: Laura Sánchez,32.000 y 
#su puesto jefe de proyecto
#El salario final será el salario bruto - 15%
#muestra por pantalla el salario final de los trabajadores

empleado2=Empleados('Laura Sánchez',3200,'jefe de proyecto')
empleado2.verdetalles()
empleado1.consultarsalario()
empleado2.consultarsalario()

#crea clase llamada alumno
#datos del alumno:nombre, fechaMatrícula,notamedia.
#crea un método para mostrar la nota siguiendo estos criterios:
#superior a 5 hasta la nota 7 es Aprobado
#superior a 7 hasra 9 es Notable
#superior a 9 hasta 10 es Sobresaliente
#inferior a 5 es Suspenso
#crea un método para consultar los días que lleva matriculado desde hoy
class Alumno:
    def __init__(self,nombre,fechaMatricula,notamedia):
        self.nombre=nombre
        self.fechaMatricula=fechaMatricula
        self.notamedia=notamedia
    def mostarnota(self):
        if(self.notamedia<5):
            print('suspenso')
        elif(self.notamedia>=5 and self.notamedia<7):
            print('aprobado')
        elif(self.notamedia>=7 and self.notamedia<9):
            print('notable')
        else:
            print('sobresaliente')
    def diasmatriculado(self):
        hoy=datetime.today()
        print(f'hoy es {hoy}')
        fechafin=datetime.strptime(self.fechaMatricula,'%d-%m-%Y')
        print(fechafin)
        dias=hoy-fechafin
        print(f'Dias matriculado{dias}')


alumno1=Alumno('Pablo',2020/12/12,9)
alumno1.mostarnota()
alumno1.diasmatriculado()

#crea una clase llamada calculo con dos propiedades n1 y n2
#crea objeto con n1=15 y n2=7
#crea un método llamado sumar que muestra la suma de los dos números

class calcula:
    def __init__(self,n1,n2) -> None:
        self.n1=n1
        self.n2=n2
        def sumar(self):
            print(f'la suma es {self.n1+self.n2}')
            def dividir(self):
                print(f'la division es{self.n1/self.n2}')








